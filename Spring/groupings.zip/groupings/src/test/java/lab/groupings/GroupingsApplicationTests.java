package lab.groupings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GroupingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
